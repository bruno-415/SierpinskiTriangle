# ⚠️ This project has been archived ⚠️

With the development of [p5js](https://p5js.org/) and the API advances in [Processing](https://processing.org/) itself, as well as Processing.js itself having been in maintenance mode for quite a few years now, this project has been archived as of December 2018. 

Processing.js would like to thank everyone who contributed over the years: it's been an amazing project! The code will still be available in read-only mode, no releases will be pulled from any of the places it was distributed through, but the last version is, and will forever be, [v1.6.6](https://github.com/processing-js/processing-js/tree/v1.6.6).

Thank you for your support, and happy coding (with newer solutions)!
