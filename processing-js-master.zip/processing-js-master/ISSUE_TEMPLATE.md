Thank you for finding a bug in Processing.js, or having a feature request you'd like to see added.

Processing.js is not under active maintenance at the moment, lacking developers that have the time
to work on it. As such, any bug you find might take a long time to get a fix. However, if you're
interested in fixing things yourself, I (Pomax) will be more than happy to review your suggested
code changes and merge them in if they fix the problem you were having without introducing problems
due to side effects your code might have.
